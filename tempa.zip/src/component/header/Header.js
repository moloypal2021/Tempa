import React, { Component } from "react";

class Header extends Component {
  render() {
    return (
      <div>
        <nav className="bg-white">
          <div className="container mx-auto px-2 sm:px-6 lg:px-8 xl:px-10 py-8">
            <div className="relative flex items-center w-full h-16">
              <div className="mr-auto">
                {/* <!-- Mobile Nav toogle Button Start--> */}
                <button className="block lg:hidden  p-1 text-black hover:text-dark-title focus:outline-none">
                  <svg
                    width="24"
                    height="24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 12h18M3 6h13M3 18h9"
                      stroke="#000"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                {/* <!-- Mobile Nav toogle Button End--> */}

                {/* <!-- Desktop Menus Start --> */}
                <div className="flex xl:space-x-6 lg:space-x-4 hidden lg:block ">
                  <a
                    href="{#}"
                    className="text-black hover:text-dark-title py-2 rounded-md xl:text-2xl lg:text-xl "
                  >
                    Home
                  </a>
                  <a
                    href="{#}"
                    className="text-black hover:text-dark-title py-2 rounded-md xl:text-2xl lg:text-xl "
                  >
                    Shop
                  </a>
                  <a
                    href="{#}"
                    className="text-black hover:text-dark-title py-2 rounded-md xl:text-2xl lg:text-xl "
                  >
                    About
                  </a>
                  <a
                    href="{#}"
                    className="text-black hover:text-dark-title py-2 rounded-md xl:text-2xl lg:text-xl "
                  >
                    Contact
                  </a>
                </div>
                {/* <!-- Desktop Menus Start --> */}
              </div>
              {/* <!-- Logos Start --> */}
              <div className="lg:absolute lg:right-0 lg:left-0 mx-auto flex justify-center">
                <h1 className="lg:text-[40px] text-3xl font-bold text-black">
                  Tempa
                </h1>
              </div>
              {/* <!-- Logos End --> */}

              {/* <!-- Shoping Cart Start --> */}
              <div className="flex items-center ml-auto">
                <button className="p-1 text-black hover:text-dark-title focus:outline-none">
                  <svg
                    width="32"
                    height="32"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M5.402 11.893a1.333 1.333 0 011.329-1.226h18.538a1.334 1.334 0 011.33 1.226l1.17 14.56a2.667 2.667 0 01-2.658 2.88H6.89a2.667 2.667 0 01-2.658-2.88L5.4 11.893h.002z"
                      stroke="#000"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M21.334 14.667V8a5.333 5.333 0 10-10.667 0v6.667"
                      stroke="#000"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>
              {/* <!-- Shoping Cart End --> */}
            </div>
          </div>

          {/* Mobile menu, show/hide based on menu stat Start  */}
          <div
            className="block lg:hidden absolute bg-dark-title bg-opacity-70 inset-0 z-50"
            x-show="mobileNav === true"
          >
            <div className="fixed left-0 max-w-[264px] w-full h-full bg-white px-4 py-6">
              <div className="flex mb-12">
                <button className="p-1 text-black hover:text-dark-title focus:outline-none">
                  <svg
                    width="32"
                    height="32"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M26.667 5.333L5.333 26.668m21.334 0L5.333 5.333l21.334 21.334z"
                      stroke="#000"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>
                <h1 className="lg:text-[40px] text-3xl font-bold text-black mx-auto pr-8">
                  Tempa
                </h1>
              </div>
              <div className="px-5">
                <a
                  href="{#}"
                  className="text-black hover:text-dark-title py-2 rounded-md sm:text-xl text-lg block"
                >
                  Home
                </a>
                <a
                  href="{#}"
                  className="text-black hover:text-dark-title py-2 rounded-md sm:text-xl text-lg block"
                >
                  Shop
                </a>
                <a
                  href="{#}"
                  className="text-black hover:text-dark-title py-2 rounded-md sm:text-xl text-lg block"
                >
                  About
                </a>
                <a
                  href="{#}"
                  className="text-black hover:text-dark-title py-2 rounded-md sm:text-xl text-lg block"
                >
                  Contact
                </a>
              </div>
            </div>
          </div>
          {/* Mobile menu, show/hide based on menu state End */}
        </nav>
      </div>
    );
  }
}

export default Header;
